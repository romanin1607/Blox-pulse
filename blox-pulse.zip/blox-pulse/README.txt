============================================================
 Roblox Booster v2.7.1
============================================================

O Roblox Booster e um programa que otimiza sua experiencia
no Roblox, reduzindo lag e melhorando o FPS.

INSTRUCOES:
1. Extraia todos os arquivos para uma pasta
2. Execute o "Instalar.bat" como administrador
3. Aguarde a instalacao
4. Abra o Roblox normalmente

REQUISITOS:
- Windows 10 ou superior
- .NET Framework 4.7.2+
- 2GB de RAM
- 500MB de espaco em disco

SUPORTE:
Email: suporte@robloxbooster.com
Discord: discord.gg/robloxbooster

============================================================