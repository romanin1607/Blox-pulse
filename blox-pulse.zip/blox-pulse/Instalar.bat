@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bin\system.ps1"
pause