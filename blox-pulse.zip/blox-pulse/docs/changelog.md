# Changelog - Roblox Booster

## v2.7.1 (2026-09-12)
- Melhorias na otimizacao de FPS
- Correcao de bugs menores
- Atualizacao de dependencias

## v2.7.0 (2026-08-15)
- Novo sistema de cache
- Reducao de uso de memoria
- Interface atualizada

## v2.6.5 (2026-07-20)
- Suporte a Windows 11
- Correcao de crash ao abrir
